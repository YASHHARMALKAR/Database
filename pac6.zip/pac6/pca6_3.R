values <- 1:10

plot(values, type="o", col="blue", lty=2, lwd=2, xlab="Index", ylab="Value", main="Dotted Line Plot")
