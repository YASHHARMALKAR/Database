age1 <- c(5, 7, 8, 7, 2, 2, 9, 4, 11, 12, 9, 6)
speed1 <- c(99, 86, 87, 88, 111, 103, 87, 94, 78, 77, 85, 86)

age2 <- c(2, 2, 8, 1, 15, 8, 12, 9, 7, 3, 11, 4, 7, 14, 12)
speed2 <- c(100, 105, 84, 105, 90, 99, 90, 95, 94, 100, 79, 112, 91, 80, 85)

plot(age1, speed1, col="blue", pch=16, xlim=c(0, 16), ylim=c(75, 115),
     xlab="Car Age (Years)", ylab="Speed (km/h)", main="Scatterplot Comparing Observations of Two Days")

points(age2, speed2, col="red", pch=17)
legend("topright", legend=c("Day 1", "Day 2"), col=c("blue", "red"), pch=c(16, 17))
