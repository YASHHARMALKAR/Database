setwd("C:/Users/yash/OneDrive/Desktop/study/sQL")
data <- read.csv("employee.csv")
print(data)

dim(data)

Clerk <- subset (data,Designation == "Clerk")
print(Clerk)
print(amount)

write.csv(amount,"output.csv")
amount <- subset (data,Salary >= 55000)
print(amount)

data1 <- read.csv("output.csv")
print(data1)

summary(data)
summary(amount)