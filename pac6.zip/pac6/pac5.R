carName="Volvo"
print(carName)

txt="Hello"
paste(txt,"world")

x<- 10.5
myvar<- 30
class(x)
class(myvar)

sqrt(100)

str<- "Yash Bharat Harmalkar"
nchar(str)

num <- 20:50
print(num)
mean_val<- mean(20:60)
print(mean_val)
sum_value<- sum(51:91)
print(sum_value)

num_vec <-c(1,2.3,3,4,5)
char_vec <-c("a","b","c","d")
log_vec <-c(TRUE,FALSE<TRUE)
print(num_vec)
print(typeof(num_vec))
print(char_vec)
print(typeof(char_vec))
print(log_vec)
print(typeof(log_vec))

name <-c('yash','aman','ram','pramod','anish')
score <- c(20.2, 20.1,  19.9, 19.2, 19.5)
attempts<- c(1 , 2,    3,      4,    5)
qulaify<- c('yes','no','yes','no','yes')
df <- data.frame(name,score,attempts,qulaify)
print(df)

df1<- data.frame(name <-c('yash','aman','ram','pramod','anish'),
			score <- c(20.2, 20.1,  19.9, 19.2, 19.5),
			attempts<- c(1 , 2,    3,      4,    5),
			qulaify<- c('yes','no','yes','no','yes'))
col<- df1$score
print(col)