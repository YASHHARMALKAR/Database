# Data for the pie chart
categories <- c('Comedy', 'Action', 'Drama', 'Romance', 'Sci-Fi')
percentages <- c(25, 30, 20, 15, 10)

# Calculate the percentage labels for the chart
percent_labels <- paste(categories, "(", percentages, "%)", sep="")

# Create a pie chart with percentages displayed
colors <- c('#ff9999', '#66b3ff', '#99ff99', '#ffcc99', '#c2c2f0')
pie(percentages, labels = percent_labels, col = colors, main = "Favorite Movie Categories", 
    clockwise = TRUE, radius = 1)

# Explanation for each category
explanations <- list(
  Comedy = "Comedy movies are light-hearted and aim to entertain with humor, making them a favorite for easy, fun viewing.",
  Action = "Action films, with intense sequences and stunts, appeal to those seeking adrenaline-pumping experiences.",
  Drama = "Drama movies focus on realistic storytelling and emotional depth, often resonating with viewers looking for thoughtful plots.",
  Romance = "Romantic films highlight love stories and are popular for those who enjoy emotional and heartwarming experiences.",
  Sci-Fi = "Science fiction combines futuristic elements with speculative technology, appealing to fans of imagination and the unknown."
)

# Print the explanations
print(explanations)
