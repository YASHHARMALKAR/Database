setwd("C:/Users/yash/OneDrive/Desktop/study/sQL")
data <- read.csv("input.csv")
print(data)

cat("Dimensions of the data: \n")
dim(data)

it_department <- subset(data, dept == "IT")
cat("People working in IT department: \n")
print(it_department)	

data$JoinDate <- as.Date(data$JoinDate, format="%Y-%m-%d")  # Adjust the format as necessary
joined_after_2014 <- subset(data, JoinDate >= as.Date("2014-01-01"))